import glob
import json
import urllib

import boto3
import logging
import os
from datetime import datetime
import csv

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
IS_PROD = os.environ['STAGE'] == 'PRODUCTION'


def handler(event, context):
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    sqs_cli = boto3.client('sqs',
                           endpoint_url='http://ls:4583',
                           aws_access_key_id='dummy',
                           aws_secret_access_key='dummy',
                           region_name='us-east-1')
    url = sqs_cli.get_queue_url(
        QueueName='queue'
    )['QueueUrl']
    sqs_cli.send_message(
        QueueUrl=url,
        MessageAttributes={
        },
        MessageBody=(
            key[:-4]
        )
    )
